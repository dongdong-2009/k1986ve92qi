#ifndef _GDEF_H
#define _GDEF_H

#include "MDR32Fx.h"

struct pi_reg_state{
	int32_t ki;
	int32_t kp;
	int32_t a;
	int32_t y;	
};

#define KI_DQCUR 100
#define KP_DQCUR 100
#define KI_SPD 0
#define KP_SPD 4000
#define KI_POS 0
#define KP_POS 6000

#endif
