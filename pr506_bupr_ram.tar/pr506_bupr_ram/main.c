#include "gdef.h"
#include "dsp.h"

#define NE 12
#define MAXENC (2<<(NE-1))

#define CPU_PLL_MULT 10 // PLL_CLK 80 MHz for 8 MHz ext oscillator
#define EEPROM_DEL 4
#define SYS_TICKS 80000 // 1ms for 80 MHz
//#define SYS_TICKS 8000000 // 100ms

#define RST_CLK_PLL_CONTROL_PLL_CPU_MUL_OFFS 8
#define RST_CLK_CPU_CLOCK_HCLK_SEL_OFFS 8
#define RST_CLK_CPU_CLOCK_CPU_C2_SEL_OFFS 2
#define EEPROM_CMD_Delay_OFFS 3

extern void adc_dma_init(void);
extern void adc_dma_start(void);
extern void adc_dma_wait(void);
extern uint32_t adc_dma_buffer[8];

void ClkConfig(void);
void PortConfig(void);
void ssi_init();
void dac_init();
uint32_t b2g(uint32_t b);
uint32_t g2b(uint32_t g);
void set_ram_vt();

void SysTick_Handler(void);
void TIMER3_Handler(void);
void ADC_Handler(void);

uint32_t system_time;

void (* table_interrupt_vector[48])(void) __attribute__((aligned (4*64)));

int sleep(uint32_t ms)
{
	uint32_t t = system_time + ms;
	while(system_time < t);
}

//--- Ports configuration ---
void PortConfig()
{
	MDR_RST_CLK->PER_CLOCK |= 1<<21;	 	//clock of PORTA ON	
	MDR_PORTA->FUNC = 0;
	MDR_PORTA->RXTX = 0; 
	MDR_PORTA->OE = 0xff;					/* output mode */
	MDR_PORTA->ANALOG = 0xffff;				/* digital mode */
	MDR_PORTA->PWR = 0xffff;				/* max power */
	
	// порты для ssp PB13-CLK PB14-RXD
	MDR_RST_CLK->PER_CLOCK |= 1<<22;	 						/* clock of PORTB ON */
	MDR_PORTB->FUNC &= ~( (0x3<<(13<<1)) + (0x3<<(14<<1)) );
	MDR_PORTB->FUNC |= ( (0x2<<(13<<1)) + (0x02<<(14<<1)) );  	/* альтернативная функция */
	MDR_PORTB->ANALOG |= (1<<13) + (1<<14);										/* digital */
	MDR_PORTB->PWR |= (0x3<<(13<<1)) + (0x3<<(14<<1));							/* max power of port */
	MDR_PORTB->OE |= (1<<13);
	MDR_PORTB->OE &= ~(1<<14);
	
	/* port C
	 * PC0 		nRE_1
	 * PC1 		DE_1
	 * PC14 	nRE_2
	 * PC15 	DE_2
	 * PC2-PC3 	TIM3_CH1 - Ф1
	 * PC4-PC5 	TIM3_CH2 - Ф2
	 * PC6-PC7 	TIM3_CH3 - Ф3
	 * PC8-PC9 	TIM3_CH4 - тормозная муфта
	 */
	MDR_RST_CLK->PER_CLOCK |= 1<<23;	 						/* clock of PORTC ON */	
	// альтернативная функция
	MDR_PORTC->FUNC = (0x02 << (2<<1)) + (0x02 << (3<<1)) +
					  (0x02 << (4<<1)) + (0x02 << (5<<1)) +
					  (0x02 << (6<<1)) + (0x02 << (7<<1)) +
					  (0x02 << (8<<1)) + (0x02 << (9<<1));
	
	MDR_PORTC->ANALOG  = 0xffff;													/* all digital */
	MDR_PORTC->PWR = 0xffffffff;													/* max power of port */
	MDR_PORTC->OE =  0xffff;
	MDR_PORTC->RXTX &= ~((1<<0) + (1<<1));
	MDR_PORTC->RXTX |= ((1<<14) + (1<<15));
	
	// port F
	MDR_RST_CLK->PER_CLOCK |= 1<<29;	 						/* clock of PORTF ON */
	MDR_PORTF->FUNC = 0;
	MDR_PORTF->OE |= (1<<14) + (1<<15);					/* output mode */
	MDR_PORTF->ANALOG |= (1<<14) + (1<<15);				/* digital mode */
	MDR_PORTF->PWR = 0xffffffff;						/* max power */	
	MDR_PORTF->RXTX |= ((1<<14) + (1<<15));
	
	// выход для dac1 dac2
	MDR_RST_CLK->PER_CLOCK |= 1<<25;	 				//clock of PORTE ON	
	MDR_PORTE->ANALOG &= ~((1<<0)+(1<<9)); // pe0 - dac2 out pe9 - dac1 out
	
	// inputs for adc
	MDR_RST_CLK->PER_CLOCK |= 1<<24;	 				//clock of PORTD ON	
	MDR_PORTD->ANALOG &= ~( (1<<7) + (1<<8) ); 			// PD5...PD11 входы АЦП
}

void ssi_init()
{
	MDR_RST_CLK->PER_CLOCK |= 1<<8;	 				//clock of SPI1
	MDR_RST_CLK->SSP_CLOCK = (1<<RST_CLK_SSP_CLOCK_SSP1_CLK_EN_Pos) | (10 << RST_CLK_SSP_CLOCK_SSP1_BRG_Pos); // SSP1_CLK = HCLK
	
	MDR_SSP1->CR1 = 0;	
	MDR_SSP1->CPSR = 10; // предделитель
	//MDR_SSP1->CR0 = (0x02 << SSP_CR0_SCR_Pos) + (0x00 << SSP_CR0_FRF_Pos) | (11 << SSP_CR0_DSS_Pos) | SSP_CR0_SPO;
	MDR_SSP1->CR0 = (0x02 << SSP_CR0_SCR_Pos) + (0x01 << SSP_CR0_FRF_Pos) + ((16-1) << SSP_CR0_DSS_Pos);
	MDR_SSP1->CR1 = SSP_CR1_SSE; // enable ssp
}

uint32_t b2g(uint32_t b)
{
	return b ^ (b >> 1);
}

uint32_t g2b(uint32_t g)
{
	uint32_t b = 0;
	for(b = 0; g; (g = g >> 1)){
		b = b ^ g;
	}
	return b;
}

uint32_t enc_crc(uint32_t e)
{
	static uint32_t code = 0;
	uint32_t crc;
	uint32_t b = e;
	
	for(crc=0; b; (b = b>>1)) crc = crc ^ b;		
	(1&crc) || (code = (MAXENC-1) & e);

	return code;
}

void adc_init()
{
	MDR_RST_CLK->PER_CLOCK |= (1<<17);
	MDR_RST_CLK->ADC_MCO_CLOCK = (0x02 << 4) + (1 << 13);  // fadc=fSHE=8MHz
	 
	// множ преобр
	MDR_ADC->ADC1_CFG = 0 ;
	MDR_ADC->ADC1_CFG |= ADC1_CFG_REG_ADON + ADC1_CFG_REG_CLKS +
					 ADC1_CFG_REG_CHCH;    							// переключение каналов выбранных в регистре CHSEL
					 				
	MDR_ADC->ADC1_CHSEL |= (1<<7) + (1<<8); 				// выбор каналов для авт переключения
	MDR_ADC->ADC1_STATUS = ADC_STATUS_ECOIF_IE; 							// прерывание по окончанию преобразования
	//MDR_ADC->ADC1_CFG |= ADC1_CFG_REG_SAMPLE; 	// start ADC
	
	//NVIC_EnableIRQ(ADC_IRQn);					
}

/*
void adc_init()
{
	MDR_RST_CLK->PER_CLOCK |= (1<<17);
	MDR_RST_CLK->ADC_MCO_CLOCK = (0x02 << 4) + (1 << 13);
	
	MDR_ADC->ADC1_CFG = ADC1_CFG_REG_ADON + (8<<ADC1_CFG_REG_CHS_Pos) +
						ADC1_CFG_REG_CLKS;
}
*/


void dac_init()
{
	MDR_RST_CLK->PER_CLOCK |= (1<<18);
	MDR_DAC->CFG |= (1<<3); // dac2 on
}	

void ClkConfig(void)
{
	MDR_RST_CLK->HS_CONTROL |= 0x00000001; 					// HSE power on, in oscillator mode
	while(0 == (MDR_RST_CLK->CLOCK_STATUS & 0x00000004));	// wait for HSE ready
	
	//MDR_RST_CLK->CPU_CLOCK = 2 + (1<<8); // fHCLK = fHSE
		
	MDR_RST_CLK->CPU_CLOCK = 2 + (1<<2);   // source for CPU_C1 is HSE, fHCLK = fHSI
	// setup for PLL CPU
	MDR_RST_CLK->PLL_CONTROL = (1<<2) + ((CPU_PLL_MULT-1)<<8);
	while(0 == (MDR_RST_CLK->CLOCK_STATUS & 0x02));	// wait for PLL CPU ready	
	
	MDR_RST_CLK->CPU_CLOCK |= (0x01<<8);  // fHCLK = fCPU_C3
	
	// flash delay
	MDR_EEPROM->CMD |= (EEPROM_DEL << EEPROM_CMD_Delay_OFFS);
						   						   	
	system_time = 0;
	//SysTick_Config(SYS_TICKS);
	
}

void set_ram_vt()
{
	// copy vt with default values from flash to ram
	uint32_t i = 0;
	uint32_t *ps = 0;
	uint32_t *pd = (uint32_t*) table_interrupt_vector;
	
	for(i = 0; i < 48; i++){
		*pd++ = ps[i];
	}
	
	// set vtor
	SCB->VTOR = ((uint32_t)table_interrupt_vector);
	table_interrupt_vector[15] = SysTick_Handler;
	table_interrupt_vector[32] = TIMER3_Handler;
	table_interrupt_vector[33] = ADC_Handler;
	
}

void SysTick_Handler(void)
{
	system_time ++;
}

/*
void TimerConfig(void)
{
	// enable TIM1
	MDR_RST_CLK->PER_CLOCK |= (1 << 14); 							
	MDR_RST_CLK->TIM_CLOCK |= RST_CLK_TIM_CLOCK_TIM1_CLK_EN; 
	MDR_RST_CLK->TIM_CLOCK &= ~RST_CLK_TIM_CLOCK_TIM1_BRG_Msk; // TIM3_CLK = HCLK
	//MDR_RST_CLK->TIM_CLOCK |= (0xff << RST_CLK_TIM_CLOCK_TIM1_BRG_OFFS);
	
	MDR_TIMER1->CNT = 0;
	MDR_TIMER1->PSG = 80 - 1;  // prescaller makes 1 MHz
	MDR_TIMER1->ARR = 200 - 1;	// TIM1 period is 5 KHz
	
	MDR_TIMER1->IE |= TIMER_IE_CNT_ARR_EVENT_IE;					// enable int for CNT=ARR event
	MDR_TIMER1->CNTRL |= TIMER_CNTRL_CNT_EN; 						// start count
	NVIC_EnableIRQ(Timer1_IRQn); 									// enable in nvic int from timer1		
}
*/

void TimerConfig(void)
{
	// enable TIM3
	MDR_RST_CLK->PER_CLOCK |= (1 << 16);
	MDR_RST_CLK->TIM_CLOCK &= ~(0xff << 16);
	MDR_RST_CLK->TIM_CLOCK |= (1 << 26);
	
	MDR_TIMER3->CNT = 0;
	MDR_TIMER3->PSG = 3 - 1;   		/* prescaller */
	MDR_TIMER3->ARR = 1024 - 1;		/* TIM4 period is 26.042KHz */
	MDR_TIMER3->CCR1 = 512;
	MDR_TIMER3->CCR2 = 512;
	MDR_TIMER3->CCR3 = 512;

	// channel 1
	MDR_TIMER3->CH1_CNTRL &= ~TIMER_CH_CNTRL_OCCM_Msk;				
	
	//MDR_TIMER3->CH1_CNTRL |= (1 << TIMER_CH_CNTRL_OCCM_Pos);									// 000: REF = 1 if CNT=ARR
	//MDR_TIMER3->CH1_CNTRL |= (6 << TIMER_CH_CNTRL_OCCM_Pos);									// 110: 1, если DIR= 0 (счет вверх), CNT<CCR, иначе 0
	MDR_TIMER3->CH1_CNTRL |= (7 << TIMER_CH_CNTRL_OCCM_Pos);									// 111: 0, если DIR= 0 (счет вверх), CNT<CCR, иначе 1
	
	MDR_TIMER3->CH1_CNTRL1 &= ~(TIMER_CH_CNTRL1_SELO_Msk | TIMER_CH_CNTRL1_SELOE_Msk);		// настройка прямого выхода канала 1
	MDR_TIMER3->CH1_CNTRL1 |= (3 << TIMER_CH_CNTRL1_SELO_Pos);	    							// на прямой выход канала 1 идет сигнал с DTG
	MDR_TIMER3->CH1_CNTRL1 |= (1 << TIMER_CH_CNTRL1_SELOE_Pos);	    						// прямой выход канала 1 всегда работает на выход на OE всегда 1
	
	MDR_TIMER3->CH1_CNTRL1 &= ~(TIMER_CH_CNTRL1_NSELO_Msk | TIMER_CH_CNTRL1_NSELOE_Msk);		// настройка инверсного выхода канала 1
	MDR_TIMER3->CH1_CNTRL1 |= (3 << TIMER_CH_CNTRL1_NSELO_Pos);	    						// на инверсный выход канала 1 идет сигнал с DTG
	MDR_TIMER3->CH1_CNTRL1 |= (1 << TIMER_CH_CNTRL1_NSELOE_Pos);	    						// инверсный выход канала 1 всегда работает на выход на OE всегда 1	
	MDR_TIMER3->CH1_CNTRL2 |= (1<<3); // CRRRLD on

	// channel 2
	MDR_TIMER3->CH2_CNTRL &= ~TIMER_CH_CNTRL_OCCM_Msk;					
	MDR_TIMER3->CH2_CNTRL |= (7 << TIMER_CH_CNTRL_OCCM_Pos);									// 111: 0, если DIR= 0 (счет вверх), CNT<CCR, иначе 1
	
	MDR_TIMER3->CH2_CNTRL1 &= ~(TIMER_CH_CNTRL1_SELO_Msk | TIMER_CH_CNTRL1_SELOE_Msk);		// настройка прямого выхода канала 1
	MDR_TIMER3->CH2_CNTRL1 |= (3 << TIMER_CH_CNTRL1_SELO_Pos);	    							// на прямой выход канала 1 идет сигнал с DTG
	MDR_TIMER3->CH2_CNTRL1 |= (1 << TIMER_CH_CNTRL1_SELOE_Pos);	    						// прямой выход канала 1 всегда работает на выход на OE всегда 1
	
	MDR_TIMER3->CH2_CNTRL1 &= ~(TIMER_CH_CNTRL1_NSELO_Msk | TIMER_CH_CNTRL1_NSELOE_Msk);		// настройка инверсного выхода канала 1
	MDR_TIMER3->CH2_CNTRL1 |= (3 << TIMER_CH_CNTRL1_NSELO_Pos);	    						// на инверсный выход канала 1 идет сигнал с DTG
	MDR_TIMER3->CH2_CNTRL1 |= (1 << TIMER_CH_CNTRL1_NSELOE_Pos);	    						// инверсный выход канала 1 всегда работает на выход на OE всегда 1		
	MDR_TIMER3->CH2_CNTRL2 |= (1<<3); // CRRRLD on

	// channel 3
	MDR_TIMER3->CH3_CNTRL &= ~TIMER_CH_CNTRL_OCCM_Msk;					
	MDR_TIMER3->CH3_CNTRL |= (7 << TIMER_CH_CNTRL_OCCM_Pos);									// 111: 0, если DIR= 0 (счет вверх), CNT<CCR, иначе 1
	
	MDR_TIMER3->CH3_CNTRL1 &= ~(TIMER_CH_CNTRL1_SELO_Msk | TIMER_CH_CNTRL1_SELOE_Msk);		// настройка прямого выхода канала 1
	MDR_TIMER3->CH3_CNTRL1 |= (3 << TIMER_CH_CNTRL1_SELO_Pos);	    							// на прямой выход канала 1 идет сигнал с DTG
	MDR_TIMER3->CH3_CNTRL1 |= (1 << TIMER_CH_CNTRL1_SELOE_Pos);	    						// прямой выход канала 1 всегда работает на выход на OE всегда 1
	
	MDR_TIMER3->CH3_CNTRL1 &= ~(TIMER_CH_CNTRL1_NSELO_Msk | TIMER_CH_CNTRL1_NSELOE_Msk);		// настройка инверсного выхода канала 1
	MDR_TIMER3->CH3_CNTRL1 |= (3 << TIMER_CH_CNTRL1_NSELO_Pos);	    						// на инверсный выход канала 1 идет сигнал с DTG
	MDR_TIMER3->CH3_CNTRL1 |= (1 << TIMER_CH_CNTRL1_NSELOE_Pos);	    						// инверсный выход канала 1 всегда работает на выход на OE всегда 1		
	MDR_TIMER3->CH3_CNTRL2 |= (1<<3); // CRRRLD on

	// setting for dead time generator (DTG)
	//MDR_TIMER3->CH1_DTG |= (1 << 4);
	//MDR_TIMER3->CH1_DTG |= 15;
	MDR_TIMER3->CH1_DTG |= ((0xff&(150)) << 6); 					// delay DTG	
	MDR_TIMER3->CH2_DTG |= ((0xff&(150)) << 6); 					// delay DTG	
	MDR_TIMER3->CH3_DTG |= ((0xff&(150)) << 6); 					// delay DTG	

	MDR_TIMER3->IE |= TIMER_IE_CNT_ARR_EVENT_IE;					// прерывание по событию  ARR=CNT
	NVIC_EnableIRQ(Timer3_IRQn); 									// enable in nvic int from tim3	

	MDR_TIMER3->CNTRL = TIMER_CNTRL_CNT_EN; 						// start count up
}

static inline void encoder_start(void)
{
	MDR_SSP1->DR = 0x555; // start encoder request<---->
}

void TIMER3_Handler(void)
{
	MDR_PORTA->RXTX ^= 0x01; // PA0	
	MDR_TIMER3->STATUS = 0;
	encoder_start();
	//MDR_ADC->ADC1_CFG |= ADC1_CFG_REG_GO; 	// start adc conversion	
	adc_dma_start();
}

void ADC_Handler(void)
{
	static uint32_t i = 0;
	MDR_PORTA->RXTX ^= 0x01; // PA0
	uint32_t buf = MDR_ADC->ADC1_RESULT;
	if( 8 == (0xfff&(buf>>16))) MDR_DAC->DAC2_DATA = 0xfff&buf;	
}

int32_t get_phase(void)
{
	MDR_SSP1->DR = 0x555; // start encoder request
	while(0 == (MDR_SSP1->SR & SSP_SR_RNE));
	return g2b((MAXENC-1) & (MDR_SSP1->DR));
}

void system_init()
{
	set_ram_vt();
	ClkConfig();
	PortConfig();
	ssi_init();
	dac_init();
	adc_init();
	TimerConfig();
	adc_init();
	adc_dma_init();
}

static inline void pwm_seta(int32_t s)
{
	MDR_TIMER3->CCR1 = s+512;
}
static inline void pwm_setb(int32_t s)
{
	MDR_TIMER3->CCR2 = s+512;
}
static inline void pwm_setc(int32_t s)
{
	MDR_TIMER3->CCR3 = s+512;
}
static inline void debug_signal(int32_t s)
{
	MDR_DAC->DAC2_DATA = s+2048;
}

__attribute__ ((section(".main_sec")))
int main()
{
	uint32_t code;
	uint32_t code1 = 0;
	int32_t speed = 0;
	int i = 0;
	int32_t ia, ib, ic;	
	int32_t dca = 0, dcc = 0;	
	uint32_t tcnt = 0;	
	int32_t ed, eq, es;
	int32_t vd, vq;
	struct pi_reg_state dreg;
	struct pi_reg_state qreg;
	struct pi_reg_state sreg;
	struct pi_reg_state preg;
	int32_t fsat = 0;
	int32_t qref = 0;	
	int32_t position = 0;	
	uint32_t phase = 0;
	int32_t dq[2];	
	int32_t abc[3];		
	
	system_init();
	
	// init the regulators
	reg_init(&dreg, KI_DQCUR, KP_DQCUR);
	reg_init(&qreg, KI_DQCUR, KP_DQCUR);	
	reg_init(&sreg, KI_SPD, KP_SPD);	
	reg_init(&preg, KI_POS, KP_POS);		

	// do some init actions	
	dca = 0;
	dcc = 0;
	for(i=0; i<1024; i++)
	{
		adc_dma_wait();			
		
		dca += (0xfff&(adc_dma_buffer[1]));
		dcc += (0xfff&(adc_dma_buffer[0]));	
	}
	
	dca = dca >> 10;
	dcc = dcc >> 10;
	
	while(1){
		adc_dma_wait();
		
		// get the currents from ADC	
		ia = (0xfff&(adc_dma_buffer[1])) - dca;
		ic = (0xfff&(adc_dma_buffer[0])) - dcc;
		ib = -ia-ic;		
		
		//debug_signal(ic<<3);
		
		code = enc_crc(MDR_SSP1->DR);
		phase = code & (1024-1);								
		//MDR_DAC->DAC2_DATA = code;		
		
		tcnt++;
		if( (0x0007 & tcnt) == 0){			
			// 3kHz
			speed = get_speed(code, &position);				
		}
		
		qref = 200;
 		// current regulator debug
		/*if( (0xffff&tcnt) == 0){
			if(qref == -200) qref = 200; // 100 is abt 1A
			else qref = -200;
		}*/
		/*
		ed = qref-ic;
		reg_update(&dreg, ed , fsat);
		
		vd = dreg.y>>12;
		fsat = 0;
		if(vd > 511){
			fsat = 1;
			vd = 511;
		}		
		
		if(vd < -511){
			fsat = 1;
			vd = -511;
		}				
			
		pwm_seta(vd);
		pwm_setc(-vd);		
		continue;
		*/

		// vector sync motor controller
		phase = 1023&(phase+0);    // phase offset for correct rotor position

		// convert abc currents to dq
		abc[0] = -ia;
		abc[1] = -ib;
		abc[2] = -ic;
		abc_to_dq(abc, dq, phase);

		// get the errors
		ed = 0 - dq[0];
		eq = qref - dq[1];
		
		debug_signal(dq[1]<<2);		
		
		// regulators do its work
		reg_update(&dreg, ed , fsat);
		reg_update(&qreg, eq , fsat);
		
		// pwm modulation
		dq[0] = dreg.y>>2;
		dq[1] = qreg.y>>2;

		fsat = svpwm(abc, dq, phase);
		//fsat = sinpwm(abc, dq, phase);		

/*
		// simple sync motor controller
		dq[0] = 0;
		dq[1] = 100*1024;
		//dq_to_abc(abc, dq, 1023&(phase+100));	
		svpwm(abc, dq, 1023&(phase+0));
*/		
		// set the pwm controller
		pwm_seta(abc[0]);
		pwm_setb(abc[1]);
		pwm_setc(abc[2]);
				
	}	
	
	/*
	while(1){
		adc_dma_wait();			
		
		// get the currents from ADC	
		ia = (0xfff&(adc_dma_buffer[1])) - dca;
		ic = (0xfff&(adc_dma_buffer[0])) - dcc;
		ib = -ia-ic;		
		
		debug_signal(ic<<3);
		
		//continue;
		
		tcnt++;

		//qref = 10;
 		// current regulator debug
		if( (0x03ff&tcnt) == 0){
			if(qref == 0) qref = 100; // 100 is abt 1A
			else qref = 0;
		}
		

		ed = qref-ic;
		reg_update(&dreg, ed , fsat);
		
		vd = dreg.y>>12;
		fsat = 0;
		if(vd > 511){
			fsat = 1;
			vd = 511;
		}		
		
		if(vd < -511){
			fsat = 1;
			vd = -511;
		}				
			
		pwm_seta(vd);
		pwm_setc(-vd);

	}
*/

/*
	while(1){
		adc_dma_wait();
		MDR_DAC->DAC2_DATA = (0xfff&(adc_dma_buffer[0]));
	}
*/
	/*while(1){
		
		MDR_DAC->DAC2_DATA = 4095&(code++);
	}*/
/*	
	while(1)
	{
		//__WFI();
		//MDR_PORTA->RXTX ^= 0x01; // PA0
	
		if(MDR_SSP1->SR & SSP_SR_RFF) 
		{
			// RX FIFO is full
						
			code = g2b((MAXENC-1) & (MDR_SSP1->DR));		
			if(code > code1)
				speed = code - code1;
			else
				speed = code - code1 + 4096;
			
			code1 = code;
			
			//MDR_DAC->DAC2_DATA = speed << 4;
			MDR_DAC->DAC2_DATA = code;		
			
		}
		
		if(MDR_ADC->ADC1_STATUS & ADC_STATUS_FLG_REG_EOCIF)
		{
			//MDR_DAC->DAC2_DATA = MDR_ADC->ADC1_RESULT;
		}

	}
*/


}
