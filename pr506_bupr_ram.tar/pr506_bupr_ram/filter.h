#ifndef _FILTER_H
#define _FILTER_H

#define RF_A11 1024
#define RF_A12 -1990
#define RF_A13 973

#define RF_B11 258212
#define RF_B12 -509394
#define RF_B13 252969

#define RF_A21 1024
#define RF_A22 -1930
#define RF_A23 922

#define RF_B21 254935
#define RF_B22 -493957
#define RF_B23 243139

#define RF_SHIFTA 10
#define RF_SHIFTB 18

#endif
