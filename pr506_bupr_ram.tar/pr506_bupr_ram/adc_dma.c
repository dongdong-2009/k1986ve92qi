#include "MDR32Fx.h"

#define DMA_TRANS_NUM 2
#define DMA_DST_INC 0x02
#define DMA_DST_SZ	0x02
#define DMA_SRC_INC	0x03
#define DMA_SRC_SZ	0x02
#define DMA_CH_POS	8

struct DMA_CTR_STRUCT
{
	uint32_t	SourceEndPointer;
	uint32_t	DestinationEndPointer;
	uint32_t	Control;
	uint32_t	Unused;
};

struct DMA_CTR_STRUCT			dma_ctr_str[32]			__attribute__ ((section(".dma_sec")));
uint32_t						adc_dma_buffer[8]		__attribute__ ((section(".dma_sec")));

void adc_dma_init(void)
{

	MDR_RST_CLK->PER_CLOCK |= 1<<5;

	MDR_DMA->CTRL_BASE_PTR = (int32_t)dma_ctr_str;
	MDR_DMA->CHNL_ENABLE_CLR = 0xFFFFFFFF;		//disable all channel
	MDR_DMA->CHNL_REQ_MASK_SET = 0xFFFFFFFF;	//disable all request
	MDR_DMA->CHNL_PRI_ALT_CLR = 0xFFFFFFFF;		//all channel use primary management structure
	MDR_DMA->CHNL_USEBURST_CLR = 1<<DMA_CH_POS;			//enable dma_sreq[] for ADC
	MDR_DMA->CHNL_REQ_MASK_CLR = 1<<DMA_CH_POS;			//enable dma_sreq[] for ADC
	//MDR_DMA->CHNL_ENABLE_SET = 1<<DMA_CH_POS;			//enable channel DMA_CH_POS for ADC

	MDR_DMA->CFG=1;								//DMA enable
	
	// setting DMA control struct in SRAM
	dma_ctr_str[DMA_CH_POS].SourceEndPointer = (uint32_t)(&(MDR_ADC->ADC1_RESULT));
	dma_ctr_str[DMA_CH_POS].DestinationEndPointer = (uint32_t)(&adc_dma_buffer[1]);
	dma_ctr_str[DMA_CH_POS].Control = (DMA_DST_INC<<30) + (DMA_DST_SZ<<28) + 
							(DMA_SRC_INC<<26) + (DMA_SRC_SZ<<24) + 
							((DMA_TRANS_NUM-1)<<4) + 0x01;	
}

void adc_dma_start(void)
{
	//int buf = ADC->ADC1_RESULT;	
	MDR_ADC->ADC1_CFG |= ADC1_CFG_REG_SAMPLE; 	// start ADC
	MDR_DMA->CHNL_ENABLE_SET = 1<<DMA_CH_POS;			//enable channel DMA_CH_POS for ADC			
}

void adc_dma_wait(void)
{
	while( (dma_ctr_str[DMA_CH_POS].Control & 0x07) );	// waiting for the dma transaction to complete
	MDR_ADC->ADC1_CFG &= ~ADC1_CFG_REG_SAMPLE;  // stop ADC	
	
	// once again set control struct
	dma_ctr_str[DMA_CH_POS].Control = (DMA_DST_INC<<30) + (DMA_DST_SZ<<28) + 
									  (DMA_SRC_INC<<26) + (DMA_SRC_SZ<<24) + 
									  ((DMA_TRANS_NUM-1)<<4) + 0x01;
}
